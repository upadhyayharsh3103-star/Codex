#!/bin/bash

DISPLAY_NUM=99
VNC_PORT=5900
RESOLUTION="1280x720"

rm -f /tmp/.X${DISPLAY_NUM}-lock 2>/dev/null
rm -f /tmp/.X11-unix/X${DISPLAY_NUM} 2>/dev/null

pkill -f "Xvfb :${DISPLAY_NUM}" 2>/dev/null
pkill -f "x11vnc.*${VNC_PORT}" 2>/dev/null
pkill -f chromium 2>/dev/null

sleep 1

PROFILE_DIR="$HOME/cloud-browser-data"

echo "Setting up permanent browser profile..."
mkdir -p "$PROFILE_DIR"

echo "Cleaning up only lock files (keeping login data)..."
rm -rf "$PROFILE_DIR/SingletonLock" 2>/dev/null
rm -rf "$PROFILE_DIR/SingletonSocket" 2>/dev/null
rm -rf "$PROFILE_DIR/SingletonCookie" 2>/dev/null

echo "Starting virtual display :$DISPLAY_NUM..."
Xvfb :$DISPLAY_NUM -screen 0 ${RESOLUTION}x24 -ac -nolisten tcp &
XVFB_PID=$!
export DISPLAY=:$DISPLAY_NUM

sleep 2

echo "Starting x11vnc on port $VNC_PORT with optimized settings..."
x11vnc -display :$DISPLAY_NUM -forever -shared -rfbport $VNC_PORT -nopw -bg -o /tmp/x11vnc.log \
  -wait 10 \
  -defer 10 \
  -threads

sleep 2

echo "Starting Chromium browser with permanent profile..."
chromium --user-data-dir="$PROFILE_DIR" \
  --no-sandbox \
  --disable-dev-shm-usage \
  --disable-gpu \
  --window-size=1280,720 \
  --no-first-run \
  --start-maximized \
  --enable-features=NetworkService,NetworkServiceInProcess \
  --disable-features=RendererCodeIntegrity \
  --disable-session-crashed-bubble \
  --restore-last-session \
  "https://www.google.com" &

echo "VNC server ready on port $VNC_PORT"
echo "Display: $DISPLAY"

wait
